using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameController : MonoBehaviour
{
    [SerializeField] public SelectObject selectedObj;
    [SerializeField] public Transform generatorArea;
    [SerializeField] public GameObject objectsParent;
    [SerializeField] public GameObject[] objects;
    [SerializeField] public int levelScore;
    [SerializeField] public int pairGenNumber;
    [SerializeField] private bool isNeedToCreateObjects;
    [SerializeField] public bool isTutorial;
    

    // Start is called before the first frame update
    void Start()
    {
        if (isNeedToCreateObjects == true)
        {
            GeneratePairs(pairGenNumber);
        }
    }

    // Generate number of paired objects to scene
    void GeneratePairs(int numberOfPairs)
    {
        if (generatorArea != null)
        {
            int i;
            for (i = 0; i < numberOfPairs; i++) {
                //var p = 1;
                int n;
                var index = (int)Random.Range(0, objects.Length);
                for (n=0; n<2; n++)
                {
                    var posHandicap = new Vector3(Random.Range(-2f, 2f), Random.Range(-2f, 2f), Random.Range(-2f, 2f));

                    Instantiate(objects[index], generatorArea.position+posHandicap, Quaternion.Euler(Random.Range(-180.0f, 180.0f), Random.Range(-180.0f, 180.0f), Random.Range(-180.0f, 180.0f)),objectsParent.transform);
                }
            }
        }
    }
}
